<?php

session_start();
require 'functions.php';

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

$id = $_GET["id"];
$maskapai = query("SELECT * FROM maskapai WHERE id_maskapai = '$id'")[0];

if (isset($_POST["edit"])) {
    if (edit($_POST) > 0) {
        echo "
            <script type='text/javascript'>
                alert('Yay! data maskapai berhasil diedit!')
                window.location = 'index.php'
            </script>
        ";
    } else {
        echo "
            <script type='text/javascript'>
                alert('Yhaa .. data maskapai gagal diedit :(')
                window.location = 'index.php'
            </script>
        ";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Maskapai</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">

    <?php require '../../layouts/sidebar_admin.php'; ?>

    <div class="flex-1 p-6">
        <h1 class="text-3xl font-bold text-gray-800">Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>
        <h2 class="text-xl font-semibold text-gray-600 mt-2">Edit Maskapai</h2>

        <form action="" method="POST" enctype="multipart/form-data" class="mt-4 bg-white p-6 rounded-lg shadow-md">
            <input type="hidden" name="id_maskapai" value="<?= $maskapai["id_maskapai"]; ?>">
            
            <div class="mb-4">
                <label for="logo_maskapai" class="block text-gray-700">Logo Maskapai</label>
                <input type="file" name="logo_maskapai" id="logo_maskapai" class="form-control mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
            </div>

            <div class="mb-4">
                <label for="nama_maskapai" class="block text-gray-700">Nama Maskapai</label>
                <input type="text" name="nama_maskapai" id="nama_maskapai" class="form-control mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200" value="<?= $maskapai["nama_maskapai"]; ?>">
            </div>

            <button type="submit" name="edit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-200">
                <i class="fas fa-save mr-2"></i> Edit
            </button>
        </form>
    </div>

</body>
</html>