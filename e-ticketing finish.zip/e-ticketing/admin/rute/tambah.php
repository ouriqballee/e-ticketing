<?php

session_start();
require 'functions.php';

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

if (isset($_POST["tambah"])) {
    if (tambah($_POST) > 0) {
        echo "
            <script type='text/javascript'>
                alert('Yay! data rute berhasil ditambahkan!')
                window.location = 'index.php'
            </script>
        ";
    } else {
        echo "
            <script type='text/javascript'>
                alert('Yhaa .. data rute gagal ditambahkan :(')
                window.location = 'index.php'
            </script>
        ";
    }
}

$maskapai = query("SELECT * FROM maskapai");
$kota = query("SELECT * FROM kota");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Rute</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">

    <?php require '../../layouts/sidebar_admin.php'; ?>

    <div class="flex-1 p-6">
        <h1 class="text-3xl font-bold text-gray-800">Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>
        <h2 class="text-xl font-semibold text-gray-600 mt-2">Tambah Rute</h2>

        <form action="" method="POST" class="mt-4 bg-white p-6 rounded-lg shadow-md">
            <div class="mb-4">
                <label for="id_maskapai" class="block text-gray-700">Nama Maskapai</label>
                <select name="id_maskapai" id="id_maskapai" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
                    <?php foreach ($maskapai as $data) : ?>
                    <option value="<?= $data["id_maskapai"]; ?>"><?= $data["nama_maskapai"]; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-4">
                <label for="rute_asal" class="block text-gray-700">Rute Asal</label>
                <select name="rute_asal" id="rute_asal" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
                    <?php foreach ($kota as $data) : ?>
                    <option value="<?= $data["nama_kota"]; ?>"><?= $data["nama_kota"]; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-4">
                <label for="rute_tujuan" class="block text-gray-700">Rute Tujuan</label>
                <select name="rute_tujuan" id="rute_tujuan" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
                    <?php foreach ($kota as $data) : ?>
                    <option value="<?= $data["nama_kota"]; ?>"><?= $data["nama_kota"]; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="mb-4">
                <label for="tanggal_pergi" class="block text-gray-700">Tanggal Pergi</label>
                <input type="date" name="tanggal_pergi" id="tanggal_pergi" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-200">
            </div>

            <button type="submit" name="tambah" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-200">
                <i class="fas fa-plus mr-2"></i> Tambah
            </button>
        </form>
    </div>

</body>
</html>