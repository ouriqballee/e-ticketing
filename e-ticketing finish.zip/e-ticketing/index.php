<?php
require 'layouts/navbar.php';

$jadwal = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai 
ORDER BY tanggal_pergi, waktu_berangkat");
?>
<div class="container mx-auto px-4 py-10">
    <!-- Banner Slider -->
    <div class="relative w-3/4 h-72 md:h-80 lg:h-96 mx-auto overflow-hidden mb-6 rounded-lg shadow-lg">
        <img id="bannerImage" src="assets/images/banner1.jpg" class="w-full h-full object-cover transition-opacity duration-1000">
    </div>

    <!-- Search Bar -->
    <div class="flex justify-center mb-6">
        <input type="text" id="searchInput" placeholder="Cari penerbangan..." class="w-3/4 md:w-1/2 p-2 border rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
    </div>

    <!-- Promo Section -->
    <div class="mb-8 text-center">
        <h2 class="text-xl font-semibold">Promo Spesial</h2>
        <div class="flex flex-wrap justify-center gap-4 mt-4">
            <div class="bg-yellow-200 p-4 rounded-lg shadow-md text-center w-60">
                <h3 class="font-bold">Diskon 20%!</h3>
                <p class="text-sm">Nikmati potongan harga tiket hingga 20% untuk rute tertentu.</p>
            </div>
            <div class="bg-blue-200 p-4 rounded-lg shadow-md text-center w-60">
                <h3 class="font-bold">Gratis Bagasi</h3>
                <p class="text-sm">Pesan sekarang dan dapatkan gratis bagasi hingga 15kg.</p>
            </div>
        </div>
    </div>

    <div class="wrapper-jadwal-penerbangan mt-10">
        <h1 class="text-2xl font-bold text-center mb-6">Jadwal Penerbangan</h1>
        <hr class="mb-6">

        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4" id="jadwalContainer">
            <?php foreach($jadwal as $data) : ?>
            <div class="card-jadwal-penerbangan bg-white shadow-sm rounded-lg overflow-hidden transform transition duration-300 hover:shadow-md hover:scale-105 p-3 text-sm">
                <div class="w-full h-24 flex items-center justify-center bg-gray-100">
                    <img src="assets/images/<?= $data['logo_maskapai']; ?>" alt="<?= $data['nama_maskapai']; ?>" class="max-h-full object-contain">
                </div>
                <div class="card-body p-2">
                    <h2 class="text-md font-semibold mb-1"><?= $data['nama_maskapai']; ?></h2>
                    <p class="text-gray-600 mb-1 text-xs"><?= $data['tanggal_pergi']; ?></p>
                    <p class="text-gray-600 mb-1 text-xs"><?= $data['waktu_berangkat']; ?> - <?= $data['waktu_tiba']; ?></p>
                    <p class="text-gray-600 mb-1 text-xs"><?= $data['rute_asal']; ?> - <?= $data['rute_tujuan']; ?></p>
                    <p class="text-md font-bold mb-3">Rp <?= number_format($data['harga'], 0, ',', '.'); ?></p>
                    <a href="detail.php?id=<?= $data['id_jadwal']; ?>" class="block text-center bg-blue-600 text-white font-bold py-1 rounded text-xs hover:bg-blue-700 transition duration-200">
                        Detail
                    </a>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <p id="noResult" class="text-center text-red-500 mt-4 hidden">Maaf, kata yang Anda cari tidak ditemukan.</p>
    </div>
</div>

<script>
let index = 0;
const images = ["assets/images/banner1.jpg", "assets/images/banner2.avif", "assets/images/banner3.jpg"];
function changeBanner() {
    index = (index + 1) % images.length;
    const banner = document.getElementById('bannerImage');
    banner.style.opacity = 0;
    setTimeout(() => {
        banner.src = images[index];
        banner.style.opacity = 1;
    }, 500);
}
setInterval(changeBanner, 5000);

// Search Functionality
const searchInput = document.getElementById("searchInput");
const jadwalContainer = document.getElementById("jadwalContainer");
const jadwalCards = jadwalContainer.getElementsByClassName("card-jadwal-penerbangan");
const noResult = document.getElementById("noResult");

searchInput.addEventListener("input", function() {
    const filter = searchInput.value.toLowerCase();
    let found = false;
    for (let i = 0; i < jadwalCards.length; i++) {
        const card = jadwalCards[i];
        const text = card.innerText.toLowerCase();
        if (text.includes(filter)) {
            card.style.display = "block";
            found = true;
        } else {
            card.style.display = "none";
        }
    }
    noResult.classList.toggle("hidden", found);
});
</script>
