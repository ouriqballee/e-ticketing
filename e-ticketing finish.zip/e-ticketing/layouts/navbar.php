<?php
require 'functions.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Ticketing</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body>
    <nav class="bg-white shadow">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center h-16">
                <div class="navbar-brand">
                    <a href="index.php" class="text-xl font-bold text-blue-600">AeroGo.</a>
                </div>
                <div class="navbar-menu hidden md:flex space-x-4">
                    <a href="index.php" class="navbar-item text-gray-600 hover:text-blue-600">Home</a>
                    <a href="cart.php" class="text-gray-600 hover:text-blue-600">Cart</a>
                    <a href="riwayat-transaksi.php" class="text-gray-600 hover:text-blue-600">History Transaksi</a>
                </div>
                <div class="btn-authentication flex items-center space-x-4">
                    <?php if(isset($_SESSION['username'])) : ?>
                        <div class="text-gray-600">Halo, <?= $_SESSION['nama_lengkap']; ?></div>
                        <a href="logout.php" class="bg-blue-600 text-white font-bold py-2 px-4 rounded-md hover:bg-blue-700 transition duration-200">Logout</a>
                    <?php else : ?>
                        <a href="auth/login/" class="text-blue-600 hover:underline">Login</a>
                        <a href="auth/register/" class="text-blue-600 hover:underline">Register</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
</body>
</html>