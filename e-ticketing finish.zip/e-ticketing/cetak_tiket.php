<?php
require 'layouts/navbar.php';

if (!isset($_GET['id_order'])) {
    echo "ID Order tidak ditemukan!";
    exit;
}

$id_order = $_GET['id_order'];

// Ambil detail tiket berdasarkan ID Order
$tiket = query("SELECT 
    ot.id_order,
    ot.tanggal_transaksi,
    od.jumlah_tiket,
    od.total_harga,
    jp.waktu_berangkat,
    jp.waktu_tiba,
    r.rute_asal,
    r.rute_tujuan,
    r.tanggal_pergi,
    m.nama_maskapai,
    m.logo_maskapai
FROM order_tiket ot
INNER JOIN order_detail od ON ot.id_order = od.id_order
INNER JOIN jadwal_penerbangan jp ON od.id_penerbangan = jp.id_jadwal
INNER JOIN rute r ON jp.id_rute = r.id_rute
INNER JOIN maskapai m ON r.id_maskapai = m.id_maskapai
WHERE ot.id_order = '$id_order' LIMIT 1");

if (!$tiket) {
    echo "Data tiket tidak ditemukan!";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cetak Tiket</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 20px; }
        .ticket { border: 2px solid #000; padding: 20px; width: 50%; margin: auto; }
        .logo { width: 100px; }
        .btn-print { margin-top: 20px; padding: 10px 20px; background: #007bff; color: white; border: none; cursor: pointer; }
        @media print { .btn-print { display: none; } }
    </style>
</head>
<body>
    <div class="ticket">
        <h2>Tiket Penerbangan</h2>
        <img src="assets/images/<?= $tiket[0]['logo_maskapai']; ?>" class="logo">
        <p><strong>Maskapai:</strong> <?= $tiket[0]['nama_maskapai']; ?></p>
        <p><strong>ID Order:</strong> <?= $tiket[0]['id_order']; ?></p>
        <p><strong>Rute:</strong> <?= $tiket[0]['rute_asal']; ?> → <?= $tiket[0]['rute_tujuan']; ?></p>
        <p><strong>Tanggal:</strong> <?= date('d/m/Y', strtotime($tiket[0]['tanggal_pergi'])); ?></p>
        <p><strong>Waktu:</strong> <?= date('H:i', strtotime($tiket[0]['waktu_berangkat'])); ?> - <?= date('H:i', strtotime($tiket[0]['waktu_tiba'])); ?></p>
        <p><strong>Jumlah Tiket:</strong> <?= $tiket[0]['jumlah_tiket']; ?></p>
        <p><strong>Total Harga:</strong> Rp <?= number_format($tiket[0]['total_harga']); ?></p>
    </div>
    <button class="btn-print" onclick="window.print();">Cetak Tiket</button>
</body>
</html>
