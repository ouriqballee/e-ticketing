<?php
session_start(); // Pastikan session sudah dijalankan

// Cek apakah parameter id_jadwal tersedia di URL
if (!isset($_GET['id_jadwal'])) {
    echo "Error: ID tiket tidak ditemukan.";
    exit;
}

$id_jadwal = $_GET['id_jadwal'];

// Cek apakah tiket dengan id_jadwal tersebut ada di session cart
if (!isset($_SESSION['cart'][$id_jadwal])) {
    echo "Error: Tiket dengan ID $id_jadwal tidak ditemukan di keranjang.";
    exit;
}

// Hapus tiket dari keranjang
unset($_SESSION['cart'][$id_jadwal]);

// Tampilkan pesan sukses dan redirect ke halaman cart
echo "<script>alert('Tiket berhasil dihapus dari keranjang!'); window.location.href='cart.php';</script>";
exit;
?>