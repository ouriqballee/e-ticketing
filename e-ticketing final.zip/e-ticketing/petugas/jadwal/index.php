<?php

session_start();
require 'functions.php';

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

$jadwal = query("SELECT * FROM jadwal_penerbangan 
INNER JOIN rute ON rute.id_rute = jadwal_penerbangan.id_rute 
INNER JOIN maskapai ON rute.id_maskapai = maskapai.id_maskapai ORDER BY tanggal_pergi, waktu_berangkat");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Data Jadwal Penerbangan</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">

    <?php require '../../layouts/sidebar_petugas.php'; ?>

    <div class="flex-1 p-6">
        <h1 class="text-3xl font-bold text-gray-800">Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>
        <h2 class="text-xl font-semibold text-gray-600 mt-2">Halaman Data Jadwal Penerbangan</h2>

        <div class="mt-4 mb-6">
        <a href="tambah.php" class="inline-block bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600 mb-2">
                    Tambah Jadwal
                </a>
        </div>

        <div class="overflow-x-auto bg-white rounded-lg shadow-md">
            <table class="min-w-full border-collapse border border-gray-200">
                <thead class="bg-gray-200">
                    <tr>
                        <th class="border px-2 py-2 text-left">No</th>
                        <th class="border px-2 py-2 text-left">Nama Maskapai</th>
                        <th class="border px-2 py-2 text-left">Kapasitas</th>
                        <th class="border px-2 py-2 text-left">Rute Asal</th>
                        <th class="border px-2 py-2 text-left">Rute Tujuan</th>
                        <th class="border px-2 py-2 text-left">Tanggal Pergi</th>
                        <th class="border px-2 py-2 text-left">Waktu Berangkat</th>
                        <th class="border px-2 py-2 text-left">Waktu Tiba</th>
                        <th class="border px-2 py-2 text-left">Harga</th>
                        <th class="border px-2 py-2 text-left">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php foreach ($jadwal as $data) : ?>
                    <tr class="<?= $no % 2 == 0 ? 'bg-gray-50' : 'bg-white'; ?>">
                        <td class="border px-2 py-2"><?= $no; ?></td>
                        <td class="border px-2 py-2"><?= $data["nama_maskapai"]; ?></td>
                        <td class="border px-2 py-2"><?= $data["kapasitas_kursi"]; ?></td>
                        <td class="border px-2 py-2"><?= $data["rute_asal"]; ?></td>
                        <td class="border px-2 py-2"><?= $data["rute_tujuan"]; ?></td>
                        <td class="border px-2 py-2"><?= $data["tanggal_pergi"]; ?></td>
                        <td class="border px-2 py-2"><?= $data["waktu_berangkat"]; ?></td>
                        <td class="border px-2 py-2"><?= $data["waktu_tiba"]; ?></td>
                        <td class="border px-2 py-2">Rp <?= number_format($data["harga"]); ?></td>
                        <td class="border px-2 py-2 flex space-x-2">
                            <a href="edit.php?id=<?= $data["id_jadwal"]; ?>" class="text-blue-500 hover:underline flex items-center">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <a href="hapus.php?id=<?= $data["id_jadwal"]; ?>" class="text-red-500 hover:underline flex items-center" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')">
                                <i class="fas fa-trash"></i> Hapus
                            </a>
                        </td>
                    </tr>
                    <?php $no++; ?>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>