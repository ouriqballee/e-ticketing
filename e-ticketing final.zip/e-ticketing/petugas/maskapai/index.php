<?php

session_start();
require 'functions.php';

if(!isset($_SESSION["username"])){
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../../auth/login/index.php';
    </script>
    ";
}

$maskapai = query("SELECT * FROM maskapai");

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Maskapai</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100">

    <div class="flex h-screen bg-gray-100">

        <?php require '../../layouts/sidebar_petugas.php'; ?>

        <div class="flex-1 overflow-y-auto p-6">
            <div class="container mx-auto">
                <h1 class="text-3xl font-bold text-gray-800 mb-4">Halaman Maskapai</h1>
                <h1>Halo, <?= $_SESSION["nama_lengkap"]; ?></h1>

                <a href="tambah.php" class="inline-block bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600 mb-6">
                    Tambah Maskapai
                </a>

                <div class="bg-white shadow-md rounded-lg overflow-x-auto">
                    <table class="min-w-full border-collapse block md:table">
                        <thead class="block md:table-header-group">
                            <tr class="border border-grey-500 md:border-none block md:table-row absolute -top-full md:top-auto -left-full md:left-auto  md:relative ">
                                <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">No</th>
                                <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">Logo Maskapai</th>
                                <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">Nama Maskapai</th>
                                <th class="bg-gray-600 p-2 text-white font-bold md:border md:border-grey-500 text-left block md:table-cell">Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="block md:table-row-group">
                            <?php $no = 1; ?>
                            <?php foreach($maskapai as $data) : ?>
                            <tr class="bg-gray-300 border border-grey-500 md:border-none block md:table-row hover:bg-gray-100">
                                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell"><span class="inline-block w-1/3 md:hidden font-bold">No</span><?= $no; ?></td>
                                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell">
                                    <span class="inline-block w-1/3 md:hidden font-bold">Logo Maskapai</span>
                                    <img src="../../assets/images/<?= $data["logo_maskapai"]; ?>" alt="Logo Maskapai" class="w-16 h-16 object-cover rounded-md">
                                </td>
                                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell"><span class="inline-block w-1/3 md:hidden font-bold">Nama Maskapai</span><?= $data["nama_maskapai"]; ?></td>
                                <td class="p-2 md:border md:border-grey-500 text-left block md:table-cell">
                                    <span class="inline-block w-1/3 md:hidden font-bold">Aksi</span>
                                    <a href="edit.php?id=<?= $data["id_maskapai"]; ?>" class="text-blue-500 hover:text-blue-700 mr-4">Edit</a>
                                    <a href="hapus.php?id=<?= $data["id_maskapai"]; ?>" class="text-red-500 hover:text-red-700" onClick="return confirm('Apakah anda yakin ingin menghapus data ini?')">Hapus</a>
                                </td>
                            </tr>
                            <?php $no++; ?>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>

</body>
</html>