<?php

session_start();

if (!isset($_SESSION["username"])) {
    echo "
    <script type='text/javascript'>
        alert('Silahkan login terlebih dahulu, ya!');
        window.location = '../auth/login/index.php';
    </script>
    ";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Petugas</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">

    <?php require '../layouts/sidebar_petugas.php'; ?>

    <div class="flex-1 p-6">
        <h1 class="text-3xl font-bold text-gray-800">
            <i class="fas fa-user-circle mr-2"></i> Halo, <?= $_SESSION["nama_lengkap"]; ?>
        </h1>
        <p class="mt-4 text-gray-600">Selamat datang di panel petugas. Anda dapat mengelola semua data di sini.</p>
    </div>

</body>
</html>