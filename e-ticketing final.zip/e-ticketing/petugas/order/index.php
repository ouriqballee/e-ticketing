<?php
session_start();
require 'functions.php';
require '../../layouts/sidebar_petugas.php';

// Check if admin is logged in
if (!isset($_SESSION['username']) || $_SESSION['roles'] !== 'Petugas') {
    header("Location: ../../auth/login/");
    exit;
}

// Handle verification process
if (isset($_POST['verify'])) {
    $id_order = $_POST['id_order'];
    if (verifikasiOrder($id_order)) {
        echo "<script>
                alert('Order berhasil diverifikasi!');
                window.location.href = 'index.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal memverifikasi order!');
              </script>";
    }
}

// Get active tab
$active_tab = isset($_GET['tab']) ? $_GET['tab'] : 'all';

// Prepare query based on active tab
$where_clause = "";
if ($active_tab === 'proses') {
    $where_clause = "WHERE ot.status = 'proses'";
} elseif ($active_tab === 'terverifikasi') {
    $where_clause = "WHERE ot.status = 'terverifikasi'";
}

// Get orders
$orders = query("SELECT 
    ot.id_order,
    ot.tanggal_transaksi,
    ot.status,
    od.jumlah_tiket,
    od.total_harga,
    u.nama_lengkap as nama_penumpang,
    jp.waktu_berangkat,
    jp.waktu_tiba,
    r.rute_asal,
    r.rute_tujuan,
    r.tanggal_pergi,
    m.nama_maskapai,
    m.logo_maskapai
FROM order_tiket ot
INNER JOIN order_detail od ON ot.id_order = od.id_order
INNER JOIN user u ON od.id_user = u.id_user
INNER JOIN jadwal_penerbangan jp ON od.id_penerbangan = jp.id_jadwal
INNER JOIN rute r ON jp.id_rute = r.id_rute
INNER JOIN maskapai m ON r.id_maskapai = m.id_maskapai
$where_clause
ORDER BY ot.tanggal_transaksi DESC");
?>

<div class="p-4 sm:ml-64">
    <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg mt-14">
        <div class="mb-4">
            <h2 class="text-lg font-bold">Daftar Order Tiket</h2>
        </div>

        <!-- Tabs -->
        <div class="mb-4 border-b border-gray-200">
            <ul class="flex flex-wrap -mb-px text-sm font-medium text-left" role="tablist">
                <li class="mr-2">
                    <a href="?tab=all" 
                       class="inline-block p-2 text-sm <?= $active_tab === 'all' ? 'text-blue-600 border-b-2 border-blue-600' : 'hover:text-gray-600 hover:border-gray-300' ?>">
                        Semua Order
                    </a>
                </li>
                <li class="mr-2">
                    <a href="?tab=proses"
                       class="inline-block p-2 text-sm <?= $active_tab === 'proses' ? 'text-blue-600 border-b-2 border-blue-600' : 'hover:text-gray-600 hover:border-gray-300' ?>">
                        Proses Verifikasi
                    </a>
                </li>
                <li class="mr-2">
                    <a href="?tab=terverifikasi"
                       class="inline-block p-2 text-sm <?= $active_tab === 'terverifikasi' ? 'text-blue-600 border-b-2 border-blue-600' : 'hover:text-gray-600 hover:border-gray-300' ?>">
                        Terverifikasi
                    </a>
                </li>
            </ul>
        </div>

        <!-- Table -->
        <div class="relative overflow-x-auto shadow-md sm:rounded-lg w-full max-w-4xl">
            <table class="w-full text-xs text-left text-gray-500">
                <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                    <tr>
                        <th scope="col" class="px-2 py-2">No</th>
                        <th scope="col" class="px-2 py-2">ID</th>
                        <th scope="col" class="px-2 py-2">Tanggal</th>
                        <th scope="col" class="px-2 py-2">Penumpang</th>
                        <th scope="col" class="px-2 py-2">Maskapai</th>
                        <th scope="col" class="px-2 py-2">Rute</th>
                        <th scope="col" class="px-2 py-2">Waktu</th>
                        <th scope="col" class="px-2 py-2">Status</th>
                        <th scope="col" class="px-2 py-2">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($orders)): ?>
                        <tr class="bg-white border-b">
                            <td colspan="9" class="px-2 py-2 text-center">Tidak ada data</td>
                        </tr>
                    <?php else: ?>
                        <?php $no = 1; ?>
                        <?php foreach ($orders as $order): ?>
                            <tr class="bg-white border-b hover:bg-gray-50">
                                <td class="px-2 py-2"> <?= $no++; ?> </td>
                                <td class="px-2 py-2"> <?= $order['id_order']; ?> </td>
                                <td class="px-2 py-2"> <?= date('d/m/Y', strtotime($order['tanggal_transaksi'])); ?> </td>
                                <td class="px-2 py-2"> <?= $order['nama_penumpang']; ?> </td>
                                <td class="px-2 py-2"> <?= $order['nama_maskapai']; ?> </td>
                                <td class="px-2 py-2"> <?= $order['rute_asal']; ?> - <?= $order['rute_tujuan']; ?> </td>
                                <td class="px-2 py-2"> <?= date('H:i', strtotime($order['waktu_berangkat'])); ?> - <?= date('H:i', strtotime($order['waktu_tiba'])); ?> </td>
                                <td class="px-2 py-2">
                                    <span class="px-2 py-1 rounded text-xs font-medium <?= $order['status'] === 'proses' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800' ?>">
                                        <?= ucfirst($order['status']); ?>
                                    </span>
                                </td>
                                <td class="px-2 py-2">
                                    <?php if ($order['status'] === 'proses'): ?>
                                        <form action="" method="POST">
                                            <input type="hidden" name="id_order" value="<?= $order['id_order']; ?>">
                                            <button type="submit" name="verify" onclick="return confirm('Verifikasi order ini?')" class="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded text-xs">
                                                Verifikasi
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
