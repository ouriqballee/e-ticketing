<?php 
require 'layouts/navbar.php';

// Check if user is logged in
if (!isset($_SESSION['id_user'])) {
    header("Location: auth/login/");
    exit;
}

$id_user = $_SESSION['id_user'];

// Get all transactions for the current user
$transactions = query("SELECT 
    ot.id_order,
    ot.tanggal_transaksi,
    ot.struk,
    ot.status,
    od.jumlah_tiket,
    od.total_harga,
    jp.waktu_berangkat,
    jp.waktu_tiba,
    r.rute_asal,
    r.rute_tujuan,
    r.tanggal_pergi,
    m.nama_maskapai,
    m.logo_maskapai
FROM order_tiket ot
INNER JOIN order_detail od ON ot.id_order = od.id_order
INNER JOIN jadwal_penerbangan jp ON od.id_penerbangan = jp.id_jadwal
INNER JOIN rute r ON jp.id_rute = r.id_rute
INNER JOIN maskapai m ON r.id_maskapai = m.id_maskapai
WHERE od.id_user = '$id_user'
ORDER BY ot.tanggal_transaksi DESC");
?>

<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold text-center mb-6">Riwayat Transaksi</h1>

    <?php if (empty($transactions)): ?>
        <div class="text-center text-gray-600">
            <p>Belum ada riwayat transaksi.</p>
        </div>
    <?php else: ?>
        <div class="overflow-x-auto">
            <table class="w-full bg-white shadow-lg rounded-lg overflow-hidden border">
                <thead class="bg-gray-200 text-gray-700">
                    <tr class="text-left">
                        <th class="p-4">No</th>
                        <th class="p-4">ID Order</th>
                        <th class="p-4">Tanggal</th>
                        <th class="p-4">Maskapai</th>
                        <th class="p-4">Rute</th>
                        <th class="p-4">Tanggal Pergi</th>
                        <th class="p-4">Waktu</th>
                        <th class="p-4 text-center">Tiket</th>
                        <th class="p-4 text-right">Harga</th>
                        <th class="p-4 text-center">Status</th>
                        <th class="p-4 text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; ?>
                    <?php foreach ($transactions as $transaction): ?>
                        <tr class="border-b hover:bg-gray-50">
                            <td class="p-4"><?= $no++; ?></td>
                            <td class="p-4"><?= $transaction['id_order']; ?></td>
                            <td class="p-4"><?= date('d/m/Y', strtotime($transaction['tanggal_transaksi'])); ?></td>
                            <td class="p-4 flex items-center">
                                <img src="<?= $transaction['logo_maskapai']; ?>" alt="<?= $transaction['nama_maskapai']; ?>" class="w-6 h-6 mr-2"> 
                                <?= $transaction['nama_maskapai']; ?>
                            </td>
                            <td class="p-4"><?= $transaction['rute_asal']; ?> - <?= $transaction['rute_tujuan']; ?></td>
                            <td class="p-4"><?= date('d/m/Y', strtotime($transaction['tanggal_pergi'])); ?></td>
                            <td class="p-4">
                                <?= date('H:i', strtotime($transaction['waktu_berangkat'])); ?> - 
                                <?= date('H:i', strtotime($transaction['waktu_tiba'])); ?>
                            </td>
                            <td class="p-4 text-center"><?= $transaction['jumlah_tiket']; ?></td>
                            <td class="p-4 text-right">Rp <?= number_format($transaction['total_harga']); ?></td>
                            <td class="p-4 text-center">
                                <span class="px-3 py-1 rounded-full text-sm <?php echo ($transaction['status'] === 'proses') ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'; ?>">
                                    <?= ($transaction['status'] === 'proses') ? 'Sedang Diverifikasi' : 'Terverifikasi'; ?>
                                </span>
                            </td>
                            <td class="p-4 text-center">
                                <?php if ($transaction['status'] === 'terverifikasi'): ?>
                                    <button onclick="printTicket('<?= htmlspecialchars(json_encode($transaction)); ?>')" class="bg-blue-500 text-white px-3 py-1 rounded-md text-sm hover:bg-blue-600">
                                        Cetak Tiket
                                    </button>
                                <?php else: ?>
                                    <span class="text-gray-500 text-sm">Menunggu Verifikasi</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"></script>
<script>
    function printTicket(transactionData) {
        var data = JSON.parse(transactionData);
        var printWindow = window.open('', '_blank');
        printWindow.document.write('<html><head><title>Cetak Tiket</title>');
        printWindow.document.write('<style>body { font-family: Arial, sans-serif; padding: 20px; text-align: center; } .ticket-container { border: 2px solid #000; padding: 20px; display: inline-block; } svg { width: 150px; height: 50px; }</style>');
        printWindow.document.write('</head><body>');
        printWindow.document.write('<div class="ticket-container">');
        printWindow.document.write('<h2>AeroGo - Tiket Penerbangan</h2>');
        printWindow.document.write('<p>ID Order: ' + data.id_order + '</p>');
        printWindow.document.write('<p>Maskapai: ' + data.nama_maskapai + '</p>');
        printWindow.document.write('<p>Rute: ' + data.rute_asal + ' - ' + data.rute_tujuan + '</p>');
        printWindow.document.write('<p>Tanggal Pergi: ' + data.tanggal_pergi + '</p>');
        printWindow.document.write('<p>Waktu: ' + data.waktu_berangkat + ' - ' + data.waktu_tiba + '</p>');
        printWindow.document.write('<p>Jumlah Tiket: ' + data.jumlah_tiket + '</p>');
        printWindow.document.write('<p>Total Harga: Rp ' + new Intl.NumberFormat('id-ID').format(data.total_harga) + '</p>');
        printWindow.document.write('<svg id="barcode"></svg>');
        printWindow.document.write('</div>');
        printWindow.document.write('<script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.0/dist/JsBarcode.all.min.js"><\/script>');
        printWindow.document.write('<script>JsBarcode("#barcode", "' + data.id_order + '").render();<\/script>');
        printWindow.document.write('</body></html>');
        printWindow.document.close();
        setTimeout(() => { printWindow.print(); }, 500);
    }
</script>
