<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Login</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gradient-to-r from-blue-400 to-indigo-600 flex items-center justify-center min-h-screen">

    <div class="bg-white p-8 rounded-lg shadow-lg w-96 md:w-80 lg:w-96 transition-transform transform hover:scale-105">
        <h3 class="text-3xl font-bold text-center mb-2 text-gray-800">AeroGo <span class="text-blue-500 text-4xl">✈️</span></h3>
        <h4 class="text-md text-gray-500 text-center mb-6">Login to your account</h4>

        <form action="process.php" method="POST">
            <div class="mb-4">
                <label for="username" class="block text-gray-700 font-semibold">Username</label>
                <div class="flex items-center border border-gray-300 rounded-md overflow-hidden">
                    <span class="p-2 text-gray-500 bg-gray-100"><i class="fas fa-user"></i></span>
                    <input type="text" name="username" id="username" class="p-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Enter your username">
                </div>
            </div>

            <div class="mb-4">
                <label for="password" class="block text-gray-700 font-semibold">Password</label>
                <div class="flex items-center border border-gray-300 rounded-md overflow-hidden">
                    <span class="p-2 text-gray-500 bg-gray-100"><i class="fas fa-lock"></i></span>
                    <input type="password" name="password" id="password" class="p-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Enter your password">
                </div>
            </div>

            <button type="submit" name="login" class="bg-blue-500 text-white px-4 py-2 rounded-lg w-full hover:bg-blue-600 transition duration-300 shadow-md">Login</button>
        </form>

        <div class="mt-4 text-center">
            <p class="text-gray-600">Belum punya akun? <a href="../register/index.php" class="text-blue-500 hover:underline">Register di sini</a></p>
        </div>
    </div>

</body>
</html>
