<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sidebar Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="bg-gray-100 flex">

    <!-- Sidebar -->
    <div class="bg-blue-600 text-white w-64 min-h-screen p-5">
        <h2 class="text-2xl font-bold mb-6">Petugas Panel</h2>
        <nav>
            <ul>
                <li class="mb-4">
                    <a href="/e-ticketing/petugas/index.php" class="flex items-center hover:bg-blue-700 p-2 rounded transition duration-200">
                        <i class="fas fa-tachometer-alt mr-2"></i> Dashboard
                    </a>
                <li class="mb-4">
                    <a href="/e-ticketing/petugas/maskapai/" class="flex items-center hover:bg-blue-700 p-2 rounded transition duration-200">
                        <i class="fas fa-plane mr-2"></i> Data Maskapai
                    </a>
                </li>
                <li class="mb-4">
                    <a href="/e-ticketing/petugas/kota/" class="flex items-center hover:bg-blue-700 p-2 rounded transition duration-200">
                        <i class="fas fa-map-marker-alt mr-2"></i> Data Kota
                    </a>
                </li>
                <li class="mb-4">
                    <a href="/e-ticketing/petugas/rute/" class="flex items-center hover:bg-blue-700 p-2 rounded transition duration-200">
                        <i class="fas fa-route mr-2"></i> Data Rute
                    </a>
                </li>
                <li class="mb-4">
                    <a href="/e-ticketing/petugas/jadwal/" class="flex items-center hover:bg-blue-700 p-2 rounded transition duration-200">
                        <i class="fas fa-calendar-alt mr-2"></i> Data Jadwal Penerbangan
                    </a>
                </li>
                <li class="mb-4">
                    <a href="/e-ticketing/petugas/order/" class="flex items-center hover:bg-blue-700 p-2 rounded transition duration-200">
                        <i class="fas fa-ticket-alt mr-2"></i> Pemesanan Tiket
                    </a>
                </li>
                <li>
                    <a href="../../logout.php" onClick="return confirm('Apakah anda yakin ingin logout?')" class="flex items-center hover:bg-red-600 p-2 rounded transition duration-200">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </a>
                </li>
            </ul>
        </nav>
    </div>

</body>
</html>